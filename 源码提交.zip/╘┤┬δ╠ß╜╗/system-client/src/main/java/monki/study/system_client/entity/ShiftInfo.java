package monki.study.system_client.entity;
//班次信息
public class ShiftInfo {
}
